const assert = require("assert").strict;
let { testIBM } = require("./lib/myscript.js");
console.log("Start to test");
testIBM();